import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:wave/config.dart';
import 'package:wave/wave.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
//State<HomePage> createState() {return _HomePageState();}
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final TextEditingController _controller = TextEditingController();
  late AnimationController _animationController;
  late Animation<Offset> _animation;
  final ValueNotifier<int> char = ValueNotifier<int>(97);
  final FocusNode _focusNode = FocusNode();
  //late Timer timer;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _focusNode.addListener(_handleFocusChange);
    RawKeyboard.instance.addListener(_handleKeyPress);
    _animationController =
        AnimationController(vsync: this, duration: Duration(seconds: 4));
    _animation = Tween<Offset>(begin: Offset(0, -100), end: Offset(0, 180))
        .animate(_animationController);
    // _animation.addListener(() {
    //   Offset offset = _animation.value;
    //   print("Offset value : $offset");
    // });
    _animationController.forward();

    Timer.periodic(const Duration(seconds: 4), (timer) {
      _animationController.dispose();
      char.value = (char.value + 1);
      if (char.value > 122) {
        char.value = 97;
      }
      _animationController =
          AnimationController(vsync: this, duration: Duration(seconds: 4));
      _animation = Tween<Offset>(begin: Offset(0, -100), end: Offset(0, 180))
          .animate(_animationController);
      _animationController.forward();
    });
  }

  @override
  void dispose() {
    _animationController.dispose();
    _focusNode.removeListener(_handleFocusChange);
    RawKeyboard.instance.removeListener(_handleKeyPress);
    _controller.dispose();
    super.dispose();
  }
  void _handleFocusChange() {
    if (_focusNode.hasFocus) {
      SystemChannels.textInput.invokeMethod('TextInput.hide');
    }
  }

  void _handleKeyPress(RawKeyEvent event) {
    if (_focusNode.hasFocus && event.runtimeType == RawKeyDownEvent) {
      final String data = String.fromCharCode(event.logicalKey.keyId);
      final TextEditingValue value = TextEditingValue(
        text: _controller.text + data,
        selection: TextSelection.collapsed(offset: _controller.text.length + 1),
      );
      _controller.value = value;
    }
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colors.white,
      body: Stack(
        children: [

          WaveWidget(
            config: CustomConfig(
              colors: [
                Colors.blueAccent.withOpacity(0.8),
              ],
              durations: [4000],
              heightPercentages: [0.75],
            ),
            waveAmplitude: 35,
            //duration: 400,
            waveFrequency: 1,
            // wavePhase: 10,
            size: const Size(
              double.infinity,
              double.infinity,
            ),
          ),
          Center(
            child: Container(
              height: 250,
              width: 200,
              color: Colors.white,
              child: Center(
                child: ValueListenableBuilder(
                  valueListenable: char,
                  builder: (BuildContext context, value, Widget? child) {
                    return AnimatedBuilder(
                      animation: _animationController,
                      builder: (BuildContext context, Widget? child) {
                        return Transform.translate(
                          offset: _animation.value,
                          child: Text(
                            String.fromCharCode(char.value),
                            style: const TextStyle(fontSize: 30),
                          ),
                        );
                      },
                    );
                  },
                ),
              ),
            ),
          ),
          Positioned(
            top: 100,
            right: 20,
            child: Container(
              width: 200,
              height: 50,
              decoration: BoxDecoration(
                color: Colors.grey[200],
                borderRadius: BorderRadius.circular(10),
              ),
              child: TextField(
                //keyboardType:TextInputType.none,
                controller: _controller,
                focusNode: _focusNode,
                enabled: true,
                showCursor: true,
                onSubmitted: (value) {
                  if (value == String.fromCharCode(char.value)) {
                    char.value = char.value + 1;
                  }
                },
                decoration: const InputDecoration(
                  border: InputBorder.none,
                  hintText: 'Search',
                  icon: Icon(Icons.search),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
